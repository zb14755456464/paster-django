from django.apps import AppConfig


class Config(AppConfig):
    name = 'lico.job.test_app'
    verbose_name = 'Manager'
