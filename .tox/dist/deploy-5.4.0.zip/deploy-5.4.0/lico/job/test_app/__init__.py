
default_app_config = 'lico.job.test_app.apps.Config'
